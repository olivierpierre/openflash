#include "LogicalRequest.hpp"

LogicalRequest::LogicalRequest(uint64_t arrivalTime, uint32_t targetedFile, uint64_t offset, uint64_t size)
{
  _arrivalTime = arrivalTime;
  _targetedFile = targetedFile;
  _offset = offset;
  _size = size;
}

uint64_t LogicalRequest::getArrivalTime()
{
  return _arrivalTime;
}

uint32_t LogicalRequest::getTargetedFile()
{
  return _targetedFile;
}

uint64_t LogicalRequest::getOffset()
{
  return _offset;
}

uint64_t LogicalRequest::getSize()
{
  return _size;
}

