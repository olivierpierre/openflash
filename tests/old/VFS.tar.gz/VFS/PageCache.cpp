#include "PageCache.hpp"

PageCache::PageCache(uint32_t size, FileSet *fileSet)
{
  _size = size;
  _fileSet = fileSet;
  _usage = 0;
  
  for(int i=0; i<fileSet->getSize(); i++)
  {
    fileInPageCache tmp;
    tmp.fileId = i;
    _content.push_back(tmp);
  }
}

int PageCache::addPage(uint32_t fileId, uint32_t pageId)
{
  for(int i=0; i<_content[fileId].size(); i++)
    if(_content[fileId].
}
