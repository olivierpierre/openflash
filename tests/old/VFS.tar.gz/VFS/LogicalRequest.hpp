#ifndef LOGICAL_REQUEST_HPP
#define LOGICAL_REQUEST_HPP

#include "CommonVFS.hpp"

typedef enum
{
  LRT_READ,
  LRT_WRITE
} logical_request_type;

class LogicalRequest
{
  public:
    LogicalRequest(uint64_t arrivalTime, uint32_t targetedFile, uint64_t offset, uint64_t size);
    uint64_t getArrivalTime();
    uint32_t getTargetedFile();
    uint64_t getOffset();
    uint64_t getSize();

  private:
    logical_request_type _type;
    uint64_t _arrivalTime;
    uint32_t _targetedFile;
    uint64_t _offset;
    uint64_t _size;
};

#endif /* LOGICAL_REQUEST_HPP */
