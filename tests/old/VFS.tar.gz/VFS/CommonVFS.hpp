#ifndef COMMON_VFS_HPP
#define COMMON_VFS_HPP

#include <iostream>
#include <vector>

typedef unsigned int uint32_t;            /**< unsigned 4 bytes integer */  
typedef unsigned long long int uint64_t;  /**< unsigned 8 bytes integer */
typedef unsigned short uint16_t;          /**< unsigned 2 bytes integer */

using namespace std;

#endif /* COMMON_VFS_HPP */

