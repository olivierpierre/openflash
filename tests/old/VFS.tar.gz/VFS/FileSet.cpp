#include <fstream>
#include "FileSet.hpp"

using namespace std;

FileSet::FileSet(string filePath)
{
  uint32_t size;
  ifstream str(filePath.c_str());
  while (str >> size)
    _sizes.push_back(size);
}

uint32_t FileSet::getFileSize(uint32_t fileId)
{
  return _sizes[fileId];
}

uint32_t FileSet::getSize()
{
  return _sizes.size();
}
