#ifndef FILESET_HPP
#define FILESET_HPP

#include "CommonVFS.hpp"

class FileSet
{
  public:
    FileSet(string filePath);
    uint32_t getFileSize(uint32_t fileId);
    uint32_t getSize();
  private:
    vector<uint32_t> _sizes;
};

#endif /* FILESET_HPP */
