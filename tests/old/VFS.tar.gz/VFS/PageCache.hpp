#ifndef PAGECACHE_HPP
#define PAGECACHE_HPP

#include "CommonVFS.hpp"
#include "FileSet.hpp"

#define PAGE_SIZE 4096

typedef struct
{
  uint32_t fileId;
  vector<uint32_t> pageIds;
} fileInPageCache;

class PageCache
{
  public:
    PageCache(uint32_t size, FileSet *fileSet);
    int addPage(uint32_t fileId, uint32_t pageId);
    uint32_t bytesUsed();
    
  private:
  
    int evictPage();
  
    uint32_t _size;
    FileSet *_fileSet;
    uint32_t _usage;
    vector<fileInPageCache> _content;
};

#endif /* PAGECACHE_HPP */
