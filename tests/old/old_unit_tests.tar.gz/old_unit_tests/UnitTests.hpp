/**
 * \file UnitTests.hpp
 * \brief UnitTests class header
 * \author Pierre Olivier <pierre.olivier@univ-brest.fr>
 * \version 0.1
 * \date 2013/04/12
 *
 * UnitTests class header.
 * 
 * UnitTests are for now subdivised into categories (ex : page tests,
 * block tests, ... one for each class). To add a category :
 * 1) create a static function in the class UnitTest (like for example 
 * planeTests())
 * 2) Write that function in UnitTests.cpp (see UnitTests::planeTests()
 * implementation)
 * 3) Place a call to that function in UnitTests::runTests().
 * 
 * For now we just use assert() to make assertions, so there is no 
 * detailed report about which tests failed etc.
 */

#ifndef UNIT_TESTS_HPP
#define UNIT_TESTS_HPP

#include "FlashSystem.hpp"
#include "ErrorManager.hpp"


class UnitTests
{
	public:
		static int runTests();
};

#endif /* UNIT_TESTS_HPP */
