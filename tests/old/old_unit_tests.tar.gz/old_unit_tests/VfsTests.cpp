#define protected public
#define private public

#include "../FlashLayer/FlashLayer.hpp"
#include "../FunctionalLayer/FunctionalLayer.hpp"

int test1();

int main(int argc, char **argv)
{
  test1();
  return 0;
}

int test1()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");

  VirtualFileSystem *vfs = VirtualFileSystem::getInstance();

  vfs->vfsCreate(2, 10);
  for(int i=0; i<100; i++)
    vfs->vfsWrite(2, i*4096, 4096);

  for(int i=0; i<100; i++)
    vfs->vfsWrite(2, rand()%4095*100, rand()%4096);

  vfs->vfsWrite(2, 2, 4096);
  vfs->vfsRead(2, 0, 4096);


  vfs->vfsRead(2, 4096, 4096);



  OpenFlashDestroy();
  return 0;
}
