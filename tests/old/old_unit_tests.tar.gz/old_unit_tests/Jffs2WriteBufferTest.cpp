#define protected public
#define private public

#include "../FlashLayer/FlashLayer.hpp"
#include "../FunctionalLayer/FunctionalLayer.hpp"

#define BLK_SIZE_BYTE	(2048*64)

void init_node_vector(vector<Jffs2Node *> &v);
void init_node_vector2(vector<Jffs2Node *> &v);
void init_node_vector3(vector<Jffs2Node *> &v);
void init_node_vector4(vector<Jffs2Node *> &v);
void destroy_node_vector(vector<Jffs2Node *> &v);

int test1();
int test2();

int main(int argc, char **argv)
{
  test1();
  return 0;
}

int test2()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");
  Jffs2 *ffs = static_cast<Jffs2 *>(FlashFileSystem::getInstance());


  vector<int> test;
  test.push_back(1); test.push_back(2); test.push_back(3);

  for(int i=2; i<3; i++)
  ffs->ffsCreate(i, rand()%32);


  ffs->ffsSync();

  for(int i=0; i<(int)ffs->_files.size(); i++)
  {
    Jffs2File &f = *(ffs->_files[i]);

    cout << f._inode_num << endl;
  }

  ffs->ffsRemove(2);

  ffs->ffsSync();

//  vector<Jffs2Node *> *res = (vector<Jffs2Node *> *) flash->getPagePriv(Address(0,0,0,404,0));
//  for(int i=0; i<(int)res->size(); i++)
//  {
//    Jffs2Node *n = ((*res)[i]);
//    if(n->getType() == JFFS2_DATA)
//      cout << "Da ";
//    else
//      cout << "Di ";
//    cout << n->getInodeNum() << "v" << n->getVersion() << endl;
//  }

  OpenFlashDestroy();
  return 0;
}

int test1()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");
  Jffs2 *ffs = static_cast<Jffs2 *>(FlashFileSystem::getInstance());

  vector<Jffs2Node *> node_vec;
  init_node_vector4(node_vec);

  for(int i=0; i<(int)node_vec.size(); i++)
    ffs->_wbuf->writeNode(node_vec[i]);

  ffs->ffsSync();

  destroy_node_vector(node_vec);
  OpenFlashDestroy();
  return 0;
}

void init_node_vector(vector<Jffs2Node *> &v)
{
  /**
   * Lets try to mimic the following commands :
   * touch /mnt/flash/test.dat && dd if=/dev/urandom of=/mnt/flash/test.dat bs=4096 count=1
   * it corresponds to 1) creating a file (1 data node with size 0 and 1 dirent node whith
   * the name test.dat) then 2) trucating the file (1 data node with size 0) and then
   *  one data node with size 4096
   */
  v.push_back(new Jffs2DataNode(2, 1, 0, 0, 0));
  v.push_back(new Jffs2DirentNode(2, 1, 12));
  v.push_back(new Jffs2DataNode(2, 2, 0, 0, 0));
  v.push_back(new Jffs2DataNode(2, 3, 0, 4096, 4096));
}

void init_node_vector2(vector<Jffs2Node *> &v)
{
  /**
   * Now lets write some additional pages (still 4K)
   */
  v.push_back(new Jffs2DataNode(2, 1, 0, 0, 0));
  v.push_back(new Jffs2DirentNode(2, 1, 12));
  v.push_back(new Jffs2DataNode(2, 2, 0, 0, 0));
  v.push_back(new Jffs2DataNode(2, 3, 0, 4096, 4096));
  v.push_back(new Jffs2DataNode(2, 4, 0, 4096, 8192));
  v.push_back(new Jffs2DataNode(2, 5, 0, 4096, 12288));
  v.push_back(new Jffs2DataNode(2, 6, 0, 4096, 16384));
  v.push_back(new Jffs2DataNode(2, 7, 0, 4096, 20480));
  v.push_back(new Jffs2DataNode(2, 8, 0, 4096, 24576));
  v.push_back(new Jffs2DataNode(2, 9, 0, 4096, 28672));
}

void init_node_vector3(vector<Jffs2Node *> &v)
{
  /**
   * Now lets make 512 byte sized nodes
   */
  v.push_back(new Jffs2DataNode(2, 1, 0, 0, 0));
  v.push_back(new Jffs2DirentNode(2, 1, 12));
  v.push_back(new Jffs2DataNode(2, 2, 0, 0, 0));
  v.push_back(new Jffs2DataNode(2, 3, 0, 512, 512));
  v.push_back(new Jffs2DataNode(2, 4, 0, 512, 1024));
  v.push_back(new Jffs2DataNode(2, 5, 0, 512, 1536));
  v.push_back(new Jffs2DataNode(2, 6, 0, 512, 2048));
  v.push_back(new Jffs2DataNode(2, 7, 0, 512, 2560));
  v.push_back(new Jffs2DataNode(2, 8, 0, 512, 3072));
  v.push_back(new Jffs2DataNode(2, 9, 0, 512, 3584));
}

void init_node_vector4(vector<Jffs2Node *> &v)
{
  /**
   * Now lets jump a block
   */
  v.push_back(new Jffs2DataNode(2, 1, 0, 0, 0));
  v.push_back(new Jffs2DirentNode(2, 1, 12));
  v.push_back(new Jffs2DataNode(2, 2, 0, 0, 0));

  for(int i=0; i<35; i++)
    v.push_back(new Jffs2DataNode(2, 3+i, 4096*i, 4096, 4096*(i+1)));

}

void destroy_node_vector(vector<Jffs2Node *> &v)
{
  for(int i=0; i<(int)v.size(); i++)
    delete v[i];
}
