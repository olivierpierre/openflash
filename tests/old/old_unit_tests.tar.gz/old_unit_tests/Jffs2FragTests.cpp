#define protected public
#define private public

#include "../FlashLayer/FlashLayer.hpp"
#include "../FunctionalLayer/FunctionalLayer.hpp"

int test1();

int main(int argc, char **argv)
{
  test1();
  return 0;
}

int test1()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");

  Jffs2File f(2);
  Jffs2DataNode dn(2, 1, 0, 4096, 4096);

  f.addDataNode(dn);

  Jffs2Frag frag(0, 4096, &dn);
  f.addFrag(frag);	// Total overlap

  frag.setSize(2048);
  f.addFrag(frag);		// overlap first half left

  frag.setSize(1023);		// split
  frag.setFileOffset(3000);
  f.addFrag(frag);
  
  frag.setSize(1040);		// total overlap 2
  frag.setFileOffset(2998);
  f.addFrag(frag);

  f.printFragMap();


  OpenFlashDestroy();
  return 0;
}
