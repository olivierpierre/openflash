#define protected public
#define private public

#include "../FlashLayer/FlashLayer.hpp"
#include "../FunctionalLayer/FunctionalLayer.hpp"

#define TEST_INODE		2
#define TEST_INODE2		3

int test1();

PpcValF write(uint32_t inode_num, uint32_t page_index, uint32_t offset, uint32_t count);

int main(int argc, char **argv)
{
  test1();
  return 0;
}

int test1()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");

  Jffs2 *jffs2 = static_cast<Jffs2 *>(FlashFileSystem::getInstance());

  jffs2->ffsCreate(TEST_INODE, sizeof("test"));
  write(TEST_INODE, 0, 0, 4096);
  write(TEST_INODE, 0, 2, 1024);
  write(TEST_INODE, 0, 5, 2);
  write(TEST_INODE, 1, 0, 4096);
  jffs2->ffsSync();

  jffs2->ffsCreate(TEST_INODE2, sizeof("test2"));
  jffs2->ffsSync();
  write(TEST_INODE2, 0, 0, 4096);


  OpenFlashDestroy();
  return 0;
}

PpcValF write(uint32_t inode_num, uint32_t page_index, uint32_t offset, uint32_t count)
{
  PpcValF res = {0, 0};
  Jffs2 *jffs2 = static_cast<Jffs2 *>(FlashFileSystem::getInstance());
  res = res + jffs2->ffsWriteBegin(inode_num, page_index, offset, count);
  res = res + jffs2->ffsWriteEnd(inode_num, page_index, offset, count);

  return res;
}
