#include <iostream>
#include <cstdlib>
#include <assert.h>
#include <string>
#include <cstring>
#include <UnitTest++.h>
#include <fstream>
#include <sstream>

#include "FlashCmdList.hpp"

#include "Address.hpp"

#include "PpcGlobals.hpp"

#include "Param2.hpp"
#include "GlobalTime.hpp"

#include "InitDestroy.hpp"

#include "UnitTests.hpp"

/**
 * Check only commands validity, and their impact on the FlashSystem state,
 * no check is performed on the perf / power consumption results
 */
SUITE(FlashCommandFunctionalBehaviorTestSuite)
{
//  vector<double> res(2);

  TEST(LegacyWrite)
  {
    /* valid */
    Address addr(0,0,0,0,0);
    LegacyWrite lw1(addr);
    cout << "Legacy write t: " << lw1.getTimeTaken() << ", e: " << lw1.getEnergyConsumed() << endl;

    CHECK(flash->getPageStat(addr, LEGACY_WRITE_NUM) == 1);
    CHECK(flash->getPageState(addr) == PAGE_OCCUPIED);
    CHECK(flash->getBlockState(addr) == BLOCK_OCCUPIED);



#if 0
    /* out of range */
    addr.setPage(5000);
    LegacyWrite lw2(addr);
    lw2.checkAndExec(&res);
#endif

#if 0
    /* already written */
    addr.setPage(0);
    LegacyWrite lw3(addr);
    lw3.getTimeTaken();
#endif

#if 0
    /* non sequential */
    addr.setPage(12);
    LegacyWrite lw4(addr);
    lw4.getTimeTaken();
#endif
  }

  TEST(LegacyRead)
  {
    /* valid */
    Address addr(0,0,0,0,0);
    LegacyRead lr(addr);
    cout << "Legacy read t: " << lr.getTimeTaken() << ", e: " << lr.getEnergyConsumed() << endl;

    CHECK(flash->getPageStat(addr, LEGACY_READ_NUM) == 1);

#if 0
    /* out of range */
    addr.setPage(5000);
    LegacyRead lr2(addr);
    lr2.checkAndExec(&res);
#endif
  }

  TEST(LegacyErase)
  {
    /* valid */
    Address addr (0,0,0,0,5000);    /* <- page member is not relevant */
    LegacyErase le(addr);
    CHECK(flash->getBlockState(addr) == BLOCK_OCCUPIED);
    cout << "Legacy erase t: " << le.getTimeTaken() << ", e: " << le.getEnergyConsumed() << endl;

    CHECK(flash->getBlockState(addr) == BLOCK_FREE);
    CHECK(flash->getBlockStat(addr, LEGACY_ERASE_NUM) == 1);
    CHECK_EQUAL(-1, flash->getBlockLastWrittenOffset(addr));

#if 0
    /* out of range */
    addr.setBlock(5000);
    LegacyErase le2(addr);
    le2.checkAndExec(&res);
#endif
  }

  TEST(CacheRead)
  {
    Address startPage(0,0,0,0,0);
    int nbPagesToRead = 10;

    /* valid */
    CacheRead cr(startPage, nbPagesToRead);
    cout << "Cache read t: " << cr.getTimeTaken() << ", e: " << cr.getEnergyConsumed() << endl;

    for(int i=0; i<nbPagesToRead; i++)
    {
      Address tmp = startPage;
      tmp.setPage(startPage.getPage() + i);
      CHECK(flash->getPageStat(tmp, CACHE_READ_NUM_PAGE) == 1);
    }
    CHECK(flash->getPlaneStat(startPage, CACHE_READ_NUM_PLANE) == 1);

    /* start page out of range */
#if 0
    startPage.setPage(5000);
    CacheRead cr2(startPage, nbPagesToRead);
    cr2.checkAndExec(&res);
#endif

#if 0
    /* crossing block boundaries */
    startPage.setPage(62);
    CacheRead cr3(startPage, nbPagesToRead);
    cr3.checkAndExec(&res);
#endif
  }

  TEST(CacheWrite)
  {
    Address startPage(0,0,0,1,0);
    int nbPagesToWrite = 64;

    /* valid */
    CacheWrite cw(startPage, nbPagesToWrite);
    cout << "Cache write t: " << cw.getTimeTaken() << ", e: " << cw.getEnergyConsumed() << endl;

    CHECK(flash->getBlockState(startPage) == BLOCK_FULL);
    CHECK(flash->getPlaneStat(startPage, CACHE_WRITE_NUM_PLANE) == 1);

    /* start page out of range */
#if 0
    startPage.setPage(5000);
    CacheWrite cw2(startPage, nbPagesToWrite);
    cw2.getTimeTaken();
#endif

#if 0
    /* crossing block boundaries */
    startPage.setPage(62);
    CacheWrite cw3(startPage, nbPagesToWrite);
    cw3.getTimeTaken();
#endif

#if 0
    /* write in non free page */
    startPage.setPage(0); startPage.setBlock(0);
    LegacyWrite lwtemp(startPage);
    lwtemp.getTimeTaken();
    CacheWrite cw3(startPage, nbPagesToWrite);
    cw3.getTimeTaken();
#endif

#if 0
    /* write not seq */
    startPage.setBlock(2);
    startPage.setPage(12);
    CacheWrite cw3(startPage, 5);
    cw3.getTimeTaken();
#endif

  }

  TEST(CopyBack)
  {
    Address src(0,0,0,0,0);
    Address trgt(0,0,0,2,0);

    /* valid */
    CopyBack cb(src, trgt);
    cout << "Copy back t: " << cb.getTimeTaken() << ", e: " << cb.getEnergyConsumed() << endl;

    CHECK(flash->getPageStat(src, COPYBACK_SRC)==1);
    CHECK(flash->getPageStat(trgt, COPYBACK_TARGET)==1);
    CHECK(flash->getPlaneStat(trgt, COPYBACK_NUM)==1);
    CHECK(flash->getPageState(trgt)==PAGE_OCCUPIED);

    /* src out of range */
#if 0
    src.setPage(5000);
    CopyBack cb2(src, trgt);
    cb2.checkAndExec(&res);
#endif

#if 0
    /* target out of range */
    src.setPage(0);
    trgt.setPage(5000);
    CopyBack cb3(src, trgt);
    cb3.checkAndExec(&res);
#endif

#if 0
    /* odd / even constraint not met */
    trgt.setPage(1);
    src.setPage(0);
    CopyBack cb4(src, trgt);
    cb4.checkAndExec(&res);
#endif

#if 0
    /* target not free */
    trgt.setPage(0);
    src.setPage(0);
    CopyBack cb5(src, trgt);
    cb5.getTimeTaken();
#endif

#if 0
    /* target not sequentially written */
    trgt.setPage(2);
    src.setPage(0);
    CopyBack cb6(src, trgt);
    cb6.getTimeTaken();
#endif

#if 0
    /* src & trgt not in the same plane */
    trgt.setChannel(1);
    CopyBack cb6(src, trgt);
    cb6.checkAndExec(&res);

#endif
  }

  TEST(MultiPlaneRead)
  {
    Address a1(0,0,0,0,0), a2(0,0,1,0,0);
    vector<Address> addrs; addrs.push_back(a1); addrs.push_back(a2);

    /* valid */
    MultiPlaneRead mpr(addrs);
    cout << "Multi plane read t: " << mpr.getTimeTaken() << ", e: " << mpr.getEnergyConsumed() << endl;

    CHECK(flash->getLunStat(addrs[0], MULTIPLANE_READ_NUM) == 1 );
    CHECK(flash->getPageStat(a1, MULTIPLANE_READ_PAGE) == 1 );
    CHECK(flash->getPageStat(a2, MULTIPLANE_READ_PAGE) == 1 );

    /* valid, simple */
    MultiPlaneRead mpr1(Address(0,0,0,0,0));
    cout << "Multi plane read 2 t: " << mpr1.getTimeTaken() << ", e: " << mpr1.getEnergyConsumed() << endl;
    CHECK(flash->getLunStat(addrs[0], MULTIPLANE_READ_NUM) == 2 );
    CHECK(flash->getPageStat(a1, MULTIPLANE_READ_PAGE) == 2 );
    CHECK(flash->getPageStat(a2, MULTIPLANE_READ_PAGE) == 2 );

#if 0
    /* out of range */
//    addrs[1].setPage(5000);
//    MultiPlaneRead mpr2(addrs);
//    mpr2.checkAndExec(&res);
#endif

#if 0
    /* same plane */
//    addrs[1].setPage(0); addrs[1].setPlane(0);
//    MultiPlaneRead mpr3(addrs);
//    mpr3.checkAndExec(&res);
#endif

#if 0
    /* different luns */
//    addrs[1].setPlane(1); addrs[1].setLun(1);
//    MultiPlaneRead mpr4(addrs);
//    mpr4.checkAndExec(&res);
#endif

#if 0
    /* different block index within each plane */
//    addrs[1].setLun(0); addrs[1].setBlock(10);
//    MultiPlaneRead mpr5(addrs);
//    mpr5.checkAndExec(&res);
#endif

#if 0
    /* different channels */
    addrs[1].setChannel(1);
    MultiPlaneRead mpr5(addrs);
    mpr5.checkAndExec(&res);
#endif
  }

  TEST(MultiPlaneWrite)
  {
    Address a1(0,0,0,12,0), a2(0,0,1,12,0);
    Address addrstab[] = {a1, a2};
    vector<Address> addrs(addrstab, addrstab+ sizeof(addrstab) / sizeof(Address) );

    /* valid */
    MultiPlaneWrite mpw(addrs);
    cout << "Multi plane write t: " << mpw.getTimeTaken() << ", e: " << mpw.getEnergyConsumed() << endl;

    CHECK(flash->getPageStat(a1, MULTIPLANE_WRITE_PAGE) == 1);
    CHECK(flash->getPageStat(a2, MULTIPLANE_WRITE_PAGE) == 1);
    CHECK(flash->getLunStat(a1, MULTIPLANE_WRITE_NUM) == 1);

    /* valid simple */
    MultiPlaneWrite mpw1(Address(0,0,0,13,0));
    cout << "Multi plane write 2 t: " << mpw1.getTimeTaken() << ", e: " << mpw1.getEnergyConsumed() << endl;
    CHECK(flash->getPageStat(Address(0,0,0,13,0), MULTIPLANE_WRITE_PAGE) == 1);
    CHECK(flash->getPageStat(Address(0,0,1,13,0), MULTIPLANE_WRITE_PAGE) == 1);
    CHECK(flash->getLunStat(Address(0,0,0,0,0), MULTIPLANE_WRITE_NUM) == 2);

#if 0
    /* write on non free page */
    MultiPlaneWrite mpw2(addrs);
    mpw2.getTimeTaken();
#endif

#if 0
    /* non seq write */
    addrs[0].setPage(33);
    MultiPlaneWrite mpw3(addrs);
    mpw3.getTimeTaken();
#endif

#if 0
    /* out of range */
    addrs[1].setPage(5000);
    MultiPlaneWrite mpw2(addrs);
    mpw2.checkAndExec(&res);
#endif

#if 0
    /* same plane */
//    addrs[1].setPage(0); addrs[1].setPlane(0);
//    MultiPlaneWrite mpw3(addrs);
//    mpw3.checkAndExec(&res);
#endif

#if 0
    /* different luns */
//    addrs[1].setPlane(1); addrs[1].setLun(1);
//    MultiPlaneWrite mpw4(addrs);
//    mpw4.checkAndExec(&res);
#endif

#if 0
    /* different block indexes within each plane */
//    addrs[1].setLun(0); addrs[0].setBlock(15); addrs[1].setBlock(1);
//    MultiPlaneWrite mpw5(addrs);
//    mpw5.checkAndExec(&res);
#endif

#if 0
    /* non free page */
//    mpw.checkAndExec(&res);
#endif

#if 0
    /* non seq. write */
//    addrs[0].setPage(40); addrs[1].setPage(40);
//    MultiPlaneWrite mpw6(addrs);
//    mpw6.checkAndExec(&res);
#endif

#if 0
    /* different channels */
    addrs[0].setChannel(1);
    MultiPlaneWrite mpw6(addrs);
    mpw6.checkAndExec(&res);

#endif
  }

  TEST(MultiPlaneErase)
  {
    vector<Address> addrs; Address a1(0,0,0,0,0); Address a2(0,0,1,0,0);
    addrs.push_back(a1); addrs.push_back(a2);

    /* valid */
    MultiPlaneErase mpe(addrs);
    cout << "Multi plane erase t: " << mpe.getTimeTaken() << ", e: " << mpe.getEnergyConsumed() << endl;

    CHECK(flash->getBlockState(a1) == BLOCK_FREE);
    CHECK(flash->getBlockState(a2) == BLOCK_FREE);
    CHECK(flash->getBlockStat(a1, MULTIPLANE_ERASE_BLOCK) == 1);
    CHECK(flash->getBlockStat(a2, MULTIPLANE_ERASE_BLOCK) == 1);
    CHECK(flash->getLunStat(a1, MULTIPLANE_ERASE_NUM) == 1);

    /* valid, simple */
    MultiPlaneErase mpe1(Address(0,0,0,0,0));
    cout << "Multi plane erase 2 t: " << mpe1.getTimeTaken() << ", e: " << mpe1.getEnergyConsumed() << endl;
    CHECK(flash->getBlockState(a1) == BLOCK_FREE);
    CHECK(flash->getBlockState(a2) == BLOCK_FREE);
    CHECK(flash->getBlockStat(a1, MULTIPLANE_ERASE_BLOCK) == 2);
    CHECK(flash->getBlockStat(a2, MULTIPLANE_ERASE_BLOCK) == 2);
    CHECK(flash->getLunStat(a1, MULTIPLANE_ERASE_NUM) == 2);


#if 0
    /* out of range */
    addrs[1].setBlock(5000);
    MultiPlaneErase mpe2(addrs);
    mpe2.checkAndExec(&res);
#endif

#if 0
    /* sample plane */
    addrs[1].setPlane(0);
    MultiPlaneErase mpe3(addrs);
    mpe3.checkAndExec(&res);
#endif

#if 0
    /* different luns */
    addrs[1].setLun(1);
    MultiPlaneErase mpe4(addrs);
    mpe4.checkAndExec(&res);
#endif

#if 0
    /* different block indexes withtin planes */
    addrs[1].setBlock(12);
    MultiPlaneErase mpe5(addrs);
    mpe5.checkAndExec(&res);
#endif

#if 0
    /* different channel */
    addrs[0].setChannel(1);
    MultiPlaneErase mpe5(addrs);
    mpe5.checkAndExec(&res);
#endif
  }

  TEST(MultiPlaneCopyBack)
  {
    Address source(0,0,0,50,0), target(0,0,0,100,0);
    MultiPlaneCopyBack mpcb(source, target);
    cout << "Multi plane copy back t: " << mpcb.getTimeTaken() << ", e: " << mpcb.getEnergyConsumed() << endl;

    CHECK(flash->getPageStat(Address(0,0,0,50,0), MPCOPYBACK_SRC) == 1);
    CHECK(flash->getPageStat(Address(0,0,1,50,0), MPCOPYBACK_SRC) == 1);
    CHECK(flash->getPageStat(Address(0,0,0,100,0), MPCOPYBACK_TRGT) == 1);
    CHECK(flash->getPageStat(Address(0,0,1,100,0), MPCOPYBACK_TRGT) == 1);
    CHECK(flash->getLunStat(source, MPCOPYBACK_NUM) == 1);

    /* out of range */
#if 0
    target.setPage(5000);
    MultiPlaneCopyBack mpcb2(source, target);
    mpcb2.checkAndExec(&res);
#endif

    /* different luns */
#if 0
    target.setLun(1);
    MultiPlaneCopyBack mpcb2(source, target);
    mpcb2.checkAndExec(&res);
#endif

#if 0
    /* odd / even rule */
    target.setPage(1);
    MultiPlaneCopyBack mpcb2(source, target);
    mpcb2.checkAndExec(&res);
#endif

#if 0
    /* different channels */
    target.setChannel(1);
    MultiPlaneCopyBack mpcb2(source, target);
    mpcb2.checkAndExec(&res);
#endif

  }

  TEST(MultiPlaneCopyBack2)
  {
    vector<Address> sources; vector<Address> targets;
    sources.push_back(Address(0,0,0,1000,0)); targets.push_back(Address(0,0,0,1001,0));
    sources.push_back(Address(0,0,1,1000,0)); targets.push_back(Address(0,0,1,1001,0));

    MultiPlaneCopyBack mpcb3(sources, targets);
    cout << "Multi plane copy back 2 t: " << mpcb3.getTimeTaken() << ", e: " << mpcb3.getEnergyConsumed() << endl;

#if 0
    /* write on non free page */
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.getTimeTaken();
#endif

#if 0
    /* non seq. write */
    targets[0].setPage(12); targets[1].setPage((12));
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.getTimeTaken();
#endif

#if 0
    /* out of range */
    sources[1].setPage(5000);
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.checkAndExec(&res);
#endif

#if 0
    /* same plane */
    sources[1].setPlane(0); targets[1].setPlane(0);
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.checkAndExec(&res);
#endif

#if 0
    /* different planes for the same couple */
    sources[1].setPlane(0);
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.checkAndExec(&res);
#endif

#if 0
    /* different page member for src */
    sources[1].setPage(2);
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.checkAndExec(&res);
#endif

#if 0
    /* different page member for target */
    targets[1].setPage(2);
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.checkAndExec(&res);
#endif

#if 0
    /* same block constraint */
    sources[1].setBlock(2);
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.checkAndExec(&res);
#endif

#if 0
    /* even / odd constraint */
    sources[1].setPage(1); sources[0].setPage(1);
    MultiPlaneCopyBack mpcb4(sources, targets);
    mpcb4.checkAndExec(&res);
#endif

  }

  TEST(MultiChannelCmd)
  {
    LegacyRead lr1(Address(0,0,0,0,0));
    LegacyRead lr2(Address(1,0,0,0,0));


    vector<UniChannelCmd *> commands; commands.push_back(&lr1); commands.push_back(&lr2);

    /* valid */
    MultiChannelCmd mc(commands);
    cout << "Multi channel t: " << mc.getTimeTaken() << ", e: " << mc.getEnergyConsumed() << endl;

    CHECK_EQUAL(2, flash->getPageStat(Address(0,0,0,0,0), LEGACY_READ_NUM));
    CHECK(flash->getPageStat(Address(1,0,0,0,0), LEGACY_READ_NUM) == 1);
    CHECK(flash->getFlashSystemStat(MULTI_CHANNEL_NUM) == 1);

    LegacyRead lr3(Address(0,0,0,0,12));
    LegacyWrite lw(Address(1,0,0,0,0));
    vector<UniChannelCmd *> commands2; commands2.push_back(&lr3); commands2.push_back(&lw);
    MultiChannelCmd mc2(commands2);
    cout << "Multi channel 2 t: " << mc2.getTimeTaken() << ", e: " << mc2.getEnergyConsumed() << endl;
  }

  TEST(MultiPlaneCacheRead)
  {
    vector<Address> startAddresses; vector<int> nbPagesToRead;

    startAddresses.push_back(Address(0,0,0,0,0));
    startAddresses.push_back(Address(0,0,1,0,0));
    nbPagesToRead.push_back(64); nbPagesToRead.push_back(32);

    MultiPlaneCacheRead mpcr(startAddresses, nbPagesToRead);
    cout << "Multi plane cache read t: " << mpcr.getTimeTaken() << ", e: " << mpcr.getEnergyConsumed() << endl;


    for(int i=0; i<(int)startAddresses.size(); i++)
    {
      Address a = startAddresses[0];
      int base = a.getPage();
      for(int j=0; j<nbPagesToRead[i]; j++)
      {
        a.setPage(base + j);
        CHECK(flash->getPageStat(a, MP_CACHE_READ) == 1);
      }
    }
    CHECK(flash->getLunStat(Address(0,0,0,0,0), MPCACHEREAD_NUM) == 1);

#if 0
    /* out of range */
    startAddresses[0].setPage(5000);
    MultiPlaneCacheRead mpcr2(startAddresses, nbPagesToRead);
    mpcr2.checkAndExec(&res);
#endif

#if 0
    /* same plane */
    startAddresses[1].setPlane(0);
    MultiPlaneCacheRead mpcr2(startAddresses, nbPagesToRead);
    mpcr2.checkAndExec(&res);
#endif

#if 0
    /* different luns */
    startAddresses[1].setLun(1);
    MultiPlaneCacheRead mpcr2(startAddresses, nbPagesToRead);
    mpcr2.checkAndExec(&res);
#endif

#if 0
    /* arrays of different sizes */
    startAddresses.pop_back();
    MultiPlaneCacheRead mpcr2(startAddresses, nbPagesToRead);
    mpcr2.checkAndExec(&res);
#endif

#if 0
    /* only 1 cache read op */
    startAddresses.pop_back(); nbPagesToRead.pop_back();
    MultiPlaneCacheRead mpcr2(startAddresses, nbPagesToRead);
    mpcr2.checkAndExec(&res);
#endif

#if 0
    /* less than 2 pages read in cache mode */
    nbPagesToRead[0] = 1;
    MultiPlaneCacheRead mpcr2(startAddresses, nbPagesToRead);
    mpcr2.checkAndExec(&res);
#endif
  }

  TEST(MultiPlaneCacheWrite)
  {
    vector<Address> startPages; vector<int> nbPagesToWrite;
    startPages.push_back(Address(1,0,0,2,0));
    startPages.push_back(Address(1,0,1,2,0));
    nbPagesToWrite.push_back(64); nbPagesToWrite.push_back(64);

    MultiPlaneCacheWrite mpcw(startPages, nbPagesToWrite);
    cout << "Multi plane cache write t: " << mpcw.getTimeTaken() << ", e: " << mpcw.getEnergyConsumed() << endl;

    for(int i=0; i<(int)startPages.size(); i++)
    {
      Address a = startPages[0];
      int base = a.getPage();
      for(int j=0; j<nbPagesToWrite[i]; j++)
      {
        a.setPage(base + j);
        CHECK(flash->getPageStat(a, MP_CACHE_WRITE) == 1);
      }
    }
    CHECK(flash->getLunStat(Address(1,0,0,0,0), MPCACHEWRITE_NUM) == 1);

#if 0
    /* write on non free page */
    MultiPlaneCacheWrite mpcw2(startPages, nbPagesToWrite);
    mpcw2.getTimeTaken();
#endif

#if 0
    /* non seq. write */
    startPages[0].setBlock(3); startPages[0].setPage(12); nbPagesToWrite[0] = 12;
    MultiPlaneCacheWrite mpw2(startPages, nbPagesToWrite);
    mpw2.getTimeTaken();
#endif

#if 0
    /* out of range */
    startPages[0].setPage(5000);
    MultiPlaneCacheWrite mpcw2(startPages, nbPagesToWrite);
    mpcw2.checkAndExec(&res);
#endif

#if 0
    /* same plane */
    startPages[1].setPlane(0);
    MultiPlaneCacheWrite mpcw2(startPages, nbPagesToWrite);
    mpcw2.checkAndExec(&res);
#endif

#if 0
    /* different luns */
    startPages[1].setLun(1);
    MultiPlaneCacheWrite mpcw2(startPages, nbPagesToWrite);
    mpcw2.checkAndExec(&res);
#endif

#if 0
    /* arrays of different sizes */
    startPages.pop_back();
    MultiPlaneCacheWrite mpcw2(startPages, nbPagesToWrite);
    mpcw2.checkAndExec(&res);
#endif

#if 0
    /* only 1 cache read op */
    startPages.pop_back(); nbPagesToWrite.pop_back();
    MultiPlaneCacheWrite mpcw2(startPages, nbPagesToWrite);
    mpcw2.checkAndExec(&res);
#endif

#if 0
    /* less than 2 pages read in cache mode */
    nbPagesToWrite[0] = 1;
    MultiPlaneCacheWrite mpcw2(startPages, nbPagesToWrite);
    mpcw2.checkAndExec(&res);
#endif

  }

  TEST(MultiLunCmd)
  {
    LegacyRead lr1(Address(0,0,0,0,0));
    LegacyRead lr2(Address(0,1,0,0,1));

    vector<UniLunCmd *> commands;
    commands.push_back(&lr1); commands.push_back(&lr2);

    MultiLunCmd mlc(commands);
    cout << "Multi LUN command t: " << mlc.getTimeTaken() << ", e: " << mlc.getEnergyConsumed() << endl;

    CHECK(flash->getPageStat(Address(0,0,0,0,0), LEGACY_READ_NUM) == 4);
    CHECK(flash->getPageStat(Address(0,1,0,0,1), LEGACY_READ_NUM) == 2);
    CHECK(flash->getChannelStat(Address(0,0,0,0,0), MULTI_LUN_NUM) == 1);
  }

  TEST(MultiLunCmd2)
  {
    LegacyWrite lw1(Address(0,0,0,1234,0));
    LegacyWrite lw2(Address(0,1,0,1234,0));

//    lw1.launch();
//    lw2.launch();

  }

  TEST(LunSubJobTests)
  {
    LegacyRead lr(Address(0,0,0,0,0));
    lr.computePerfAndPc();
    vector<multiLunSubJob_t> vec = lr.getMultiLunSubJobs();

    LegacyWrite lw(Address(0,0,0,0,0));
    lw.computePerfAndPc();
    vec = lw.getMultiLunSubJobs();

    LegacyErase le(Address(0,0,0,0,0));
    le.computePerfAndPc();
    vec = le.getMultiLunSubJobs();

    CopyBack cb(Address(0,0,0,0,0), Address(0,0,0,0,0));
    cb.computePerfAndPc();
    vec = cb.getMultiLunSubJobs();

    MultiPlaneErase mpe(Address(0,0,0,0,0));
    mpe.computePerfAndPc();
    vec = mpe.getMultiLunSubJobs();

    CacheRead cr(Address(0,0,0,0,0), 3);
    cr.computePerfAndPc();
    vec = cr.getMultiLunSubJobs();

    CacheWrite cw(Address(0,0,0,0,0), 3);
    cw.computePerfAndPc();
    vec = cw.getMultiLunSubJobs();

    MultiPlaneRead mpr(Address(0,0,0,0,0));
    mpr.computePerfAndPc();
    vec = mpr.getMultiLunSubJobs();

    vector<Address> addrs;
    addrs.push_back(Address(0,0,0,0,0)); addrs.push_back(Address(0,0,1,0,1));
    MultiPlaneRead mpr2(addrs);
    mpr2.computePerfAndPc();
    vec = mpr2.getMultiLunSubJobs();

    MultiPlaneWrite mpw(Address(0,0,0,0,0));
    vec = mpw.getMultiLunSubJobs();

    vector<Address> addrs2;
    addrs2.push_back(Address(0,0,1,0,1)); addrs2.push_back(Address(0,0,0,0,0));
    MultiPlaneWrite mpw2(addrs2);
    vec = mpw2.getMultiLunSubJobs();

    MultiPlaneCopyBack mpcb(Address(0,0,0,0,0), Address(0,0,0,0,0));
    mpcb.computePerfAndPc();
    vec = mpcb.getMultiLunSubJobs();

    vector<Address> addrs3; vector<int> nbPagesToRead;
    addrs3.push_back(Address(0,0,0,0,0)); addrs3.push_back(Address(0,0,1,0,0));
    nbPagesToRead.push_back(6); nbPagesToRead.push_back(2);
    MultiPlaneCacheRead mpcr(addrs3, nbPagesToRead);
    mpcr.computePerfAndPc();
    double mpcrRes = mpcr.getTimeTaken();
    (void)mpcrRes;

    vec = mpcr.getMultiLunSubJobs();

#if 0 /* debug */
    for(int i=0; i<(int)vec.size(); i++)
      if(vec[i].type==PAR)
        cout << "PAR " << vec[i].time << " ; ";
      else
        cout << "SEQ " << vec[i].time << " ; ";
    cout << endl;
#endif

    vector<Address> addrs4; vector<int> nbPagesToWrite;
    addrs4.push_back(Address(1,1,0,0,0)); addrs4.push_back(Address(1,1,1,0,0));
    nbPagesToWrite.push_back(2); nbPagesToWrite.push_back(5);
    MultiPlaneCacheWrite mpcw(addrs4, nbPagesToWrite);
    double mpcwRes = mpcw.getTimeTaken();
    (void)mpcwRes;

    vec = mpcw.getMultiLunSubJobs();



  }

  TEST(GlobalTime)
  {
    cout << "Time elapsed: " << gtime->getGlobalTime() << endl;
  }
}

int main(int argc, char **argv)
{
  initGlobal("sampleconf.cfg");

  cout << "Running tests on " << *flash << endl;

  UnitTest::RunAllTests();

  destroyGlobal();
  return EXIT_SUCCESS;
}
