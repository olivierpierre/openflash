#define protected public
#define private public

#include "../FlashLayer/FlashLayer.hpp"
#include "../FunctionalLayer/FunctionalLayer.hpp"
#include "../TimeEvents/Parsers/TraceParser.hpp"

#include "../FunctionalLayer/FFS/Jffs2/Jffs2GC.hpp"

int test1();

int main(int argc, char **argv)
{
  test1();
  return 0;
}

int test1()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");

  VirtualFileSystem *vfs = VirtualFileSystem::getInstance();
  Jffs2 *jffs2 = static_cast<Jffs2 *>(FlashFileSystem::getInstance());

  vfs->vfsCreate(2, 10);
  vfs->vfsWrite(2, 0, 4096);
  vfs->vfsRename(2, 15);
  vfs->vfsSync();

  Jffs2Block *block= jffs2->_wbuf->_current_block;
  cout << block->getDirtySize() << endl;
  cout << block->getUsedSize() << endl;

  for(int i=0; i<(int)block->_nodes.size(); i++)
  {
    Jffs2Node *n = block->_nodes[i];
    switch(n->getType())
    {
      case JFFS2_DATA:
      {
	Jffs2DataNode *dn = static_cast<Jffs2DataNode *>(n);
	cout << *dn << endl;
	break;
      }

      case JFFS2_DIRENT:
      {
	Jffs2DirentNode *dn = static_cast<Jffs2DirentNode *>(n);
	cout << *dn << endl;
	break;
      }

      default:
	assert(0);

    }
  }

  OpenFlashDestroy();
  return 0;
}
