#define protected public
#define private public

#include "../FlashLayer/FlashLayer.hpp"
#include "../FunctionalLayer/FunctionalLayer.hpp"

int test1();

int main(int argc, char **argv)
{
  test1();
  return 0;
}

int test1()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");
  jffs2_frags_comp_t res;


  Jffs2DataNode dn(1, 1, 1, 1, 1);
  Jffs2Frag frag(5, 5, &dn);

  /* 1. No overlap at all */

  Jffs2Frag frag1(50, 12, &dn);
  assert((res = frag1.compare(frag)) == JFFS2_FRAGS_NO_OVERLAP);

  Jffs2Frag frag2(0, 2, &dn);
  assert((res = frag2.compare(frag)) == JFFS2_FRAGS_NO_OVERLAP);

  Jffs2Frag frag3(0, 5, &dn);
  assert((res = frag3.compare(frag)) == JFFS2_FRAGS_NO_OVERLAP);

  Jffs2Frag frag4(10, 2, &dn);
  assert((res = frag4.compare(frag)) == JFFS2_FRAGS_NO_OVERLAP);

  /* 2. left partial overlap */

  Jffs2Frag frag5(0, 7, &dn);
  assert((res = frag5.compare(frag)) == JFFS2_FRAGS_PARTIAL_LEFT);

  Jffs2Frag frag6(1, 5, &dn);
  assert((res = frag6.compare(frag)) == JFFS2_FRAGS_PARTIAL_LEFT);

  Jffs2Frag frag7(1, 4, &dn);
  assert((res = frag7.compare(frag)) != JFFS2_FRAGS_PARTIAL_LEFT);

  /* 3. right partial overlap */

  Jffs2Frag frag8(7, 4, &dn);
  assert((res = frag8.compare(frag)) == JFFS2_FRAGS_PARTIAL_RIGHT);

  Jffs2Frag frag9(9, 4, &dn);
  assert((res = frag9.compare(frag)) == JFFS2_FRAGS_PARTIAL_RIGHT);

  Jffs2Frag frag10(10, 4, &dn);
  assert((res = frag10.compare(frag)) != JFFS2_FRAGS_PARTIAL_RIGHT);

  /* 4. Split */
  Jffs2Frag frag11(7, 1, &dn);
  assert((res = frag11.compare(frag)) == JFFS2_FRAGS_SPLIT);

  Jffs2Frag frag12(6, 2, &dn);
  assert((res = frag12.compare(frag)) == JFFS2_FRAGS_SPLIT);

  Jffs2Frag frag13(6, 4, &dn);
  assert((res = frag13.compare(frag)) != JFFS2_FRAGS_SPLIT);

  /* 5. Total overlap */
  Jffs2Frag frag14(5, 5, &dn);
  assert((res = frag14.compare(frag)) == JFFS2_FRAGS_TOTAL_OVERLAP);

  Jffs2Frag frag15(2, 10, &dn);
  assert((res = frag15.compare(frag)) == JFFS2_FRAGS_TOTAL_OVERLAP);

  Jffs2Frag frag16(6, 2, &dn);
  assert((res = frag16.compare(frag)) != JFFS2_FRAGS_TOTAL_OVERLAP);

  OpenFlashDestroy();
  return 0;
}
