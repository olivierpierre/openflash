#define protected public
#define private public

#include "../FlashLayer/FlashLayer.hpp"
#include "../FunctionalLayer/FunctionalLayer.hpp"
#include "../TimeEvents/TimeEvents.hpp"


int test1();
int test2();

int main(int argc, char **argv)
{
  test2();
  return 0;
}

int test2()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");

  EventProcessor *ep = EventProcessor::getInstance();
  FakeAsyncEvent *ae1 = new FakeAsyncEvent(50, 0, 0, 0, 1.2);
  ep->insertAsyncEvent(*ae1);

  Event *e1 = new FakeWLEvent(0, 123);
  ep->insertWorkloadEvent(*e1);

  Event *e2 = new FakeWLEvent(50, 123);
  ep->insertWorkloadEvent(*e2);


  Event *e3 = new FakeWLEvent(500, 123);
  ep->insertWorkloadEvent(*e3);


  OpenFlashDestroy();
  return 0;
}

int test1()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");

  EventProcessor *ep = EventProcessor::getInstance();

  int inode = 2;
  FakeAsyncEvent *ae = new FakeAsyncEvent(50, 1, 10, 0, 122);

  ep->insertAsyncEvent(*ae);
  ep->insertAsyncEvent(*ae);

  ae->_arrival_time = 3000;
  ep->insertAsyncEvent(*ae);

  ae->_arrival_time = 150;
  ep->insertAsyncEvent(*ae);

  for(int i=0; i<10; i++)
  {
    Event *e = new VFSCreate(i*100, inode, 10);
    cout << inode << endl;
    ep->insertWorkloadEvent(*e);
    delete e;
    inode++;
  }

  ep->insertWorkloadEvent(*(new VFSSync(3000)));



  OpenFlashDestroy();
  return 0;
}
