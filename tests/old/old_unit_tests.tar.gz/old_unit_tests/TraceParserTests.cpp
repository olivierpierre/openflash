#define protected public
#define private public

#include "../FlashLayer/FlashLayer.hpp"
#include "../FunctionalLayer/FunctionalLayer.hpp"
#include "../TimeEvents/Parsers/TraceParser.hpp"

int test1();

int main(int argc, char **argv)
{
  test1();
  return 0;
}

int test1()
{
  OpenFlashInit("/home/pierre/Bureau/simulator-pierre/trunk/tests/ConfigFiles/sampleconf_ffs.cfg");

  TraceParser *tp = TraceParser::getInstance();
  EventProcessor *ep = EventProcessor::getInstance();

  CacheRead cr(Address(1, 2, 3, 4, 5), 2);

  Event *e;

  while((e = tp->getNextEvent()) != NULL)
  {
    ep->insertWorkloadEvent(*e);
    delete e;
  }

  OpenFlashDestroy();
  return 0;
}
